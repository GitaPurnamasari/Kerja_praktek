<?php
class Admin_model extends CI_Model
{
	public $table = 'siswa';
	public $id = 'id';
    public $order = 'DESC';

	public $labels = [];

	function __construct()
	{
		parent :: __construct();
		$this->labels = $this->_attributeLabels();
		$this->labels = $this->show_khstable();

		$this->load->database();
	}

    public function update_data($where,$data)
    {
		$this->db->where($where);
		$this->db->update('siswa',$data);
	}

	public function read()
	{
		$sql = "SELECT * FROM siswa ORDER BY id";
		$query = $this->db->query($sql);
		return $query->result();
	}

	function edit_siswa($where)
	{		
		return $this->db->get_where('siswa',$where);
	}

	function hapus_data($where)
	{
		$this->db->where($where);
		$this->db->delete('siswa');
	}

	function hapus_all()
	{
		return $this->db->get('siswa');
		return $this->db->get('tema1');
		return $this->db->get('tema1ket');
		return $this->db->get('tema2');
		return $this->db->get('tema2ket');
		return $this->db->get('tema3');
		return $this->db->get('tema3ket');
		return $this->db->get('tema4');
		return $this->db->get('tema4ket');
		return $this->db->get('tema5');
		return $this->db->get('tema5ket');
		return $this->db->get('tema6');
		return $this->db->get('tema6ket');
		return $this->db->get('tema7');
		return $this->db->get('tema7ket');
		return $this->db->get('tema8');
		return $this->db->get('tema8ket');
		return $this->db->get('tema9');
		return $this->db->get('tema9ket');
	}

	function DeleteAll()
	{
		$this->db->empty_table('siswa');
		$this->db->empty_table('tema1');
		$this->db->empty_table('tema1ket');
		$this->db->empty_table('tema2');
		$this->db->empty_table('tema2ket');
		$this->db->empty_table('tema3');
		$this->db->empty_table('tema3ket');
		$this->db->empty_table('tema4');
		$this->db->empty_table('tema4ket');
		$this->db->empty_table('tema5');
		$this->db->empty_table('tema5ket');
		$this->db->empty_table('tema6');
		$this->db->empty_table('tema6ket');
		$this->db->empty_table('tema7');
		$this->db->empty_table('tema7ket');
		$this->db->empty_table('tema8');
		$this->db->empty_table('tema8ket');
		$this->db->empty_table('tema9');
		$this->db->empty_table('tema9ket');
	}

	// get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this-> $id);
        return $this->db->get($this->table,["id" => $id])->row();
    }

	function total_rows($q = NULL) 
	{
        $this->db->like('id', $q);
		$this->db->or_like('nik', $q);
		$this->db->or_like('nama', $q);
		$this->db->or_like('kelas', $q);
		$this->db->or_like('alamat', $q);

		$this->db->from($this->table);
	        return $this->db->count_all_results();
    }

    function get_limit_data($limit, $start = 0, $q = NULL) 
    {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id', $q);
		$this->db->or_like('nik', $q);
		$this->db->or_like('nama', $q);
		$this->db->or_like('kelas', $q);
		$this->db->or_like('alamat', $q);


		$this->db->limit($limit, $start);
	        return $this->db->get($this->table);
    }

    //cek nip dan password dosen
    function auth($username,$password){
        $query=$this->db->query("SELECT * FROM user WHERE unique_id='$username' AND password=MD5('$password') LIMIT 1");
        return $query;
    }
    function signup($username = 0){
		$this->load->helper('url');
		$cek = url_title($this->input_->post('username'), 'dash', TRUE);
		$data = array(
			'unique_id' => $this->input_->post('username'), 
			'username' => $this->input_->post('fname'), 
			'password' => md5($this->input_->post('password')),
			'level' => 2
		);
		if ($username == 0){
			return $this->db->insert('user', $data);
		} else {
			$url=base_url('');
            echo $this->session->set_flashdata('msg','Username sudah ada');
            redirect($url);
		}
	}

	private function _attributeLabels()
	{
		return[
			'nik'=> 'nik',
			'nama'=> 'nama',
			'kelas'=> 'kelas',
			'alamat'=> 'alamat'
		];
	}
	public function show_khstable()
	{
		return $this->db->get('download');
	}
}