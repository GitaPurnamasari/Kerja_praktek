<?php
class kepsel_model extends CI_Model
{
	public $table = 'siswa';
	public $id = 'id';
    public $order = 'DESC';

	public $labels = [];

	function __construct()
	{
		parent :: __construct();
		$this->labels = $this->_attributeLabels();
		$this->labels = $this->show_khstable();

		$this->load->database();
	 }

    public function update_data($where,$data)
    {
		$this->db->where($where);
		$this->db->update('siswa',$data);
	}

	public function read()
	{
		$sql = "SELECT * FROM siswa ORDER BY id";
		$query = $this->db->query($sql);
		return $query->result();
	}

	function edit_siswa($where)
	{		
		return $this->db->get_where('siswa',$where);
	}

	function hapus_data($where)
	{
		$this->db->where($where);
		$this->db->delete('siswa');
	}

	// get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this-> $id);
        return $this->db->get($this->table,["id" => $id])->row();
    }

	function total_rows($q = NULL) 
	{
        $this->db->like('id', $q);
		$this->db->or_like('nik', $q);
		$this->db->or_like('nama', $q);
		$this->db->or_like('kelas', $q);
		$this->db->or_like('alamat', $q);

		$this->db->from($this->table);
	        return $this->db->count_all_results();
    }

    function get_limit_data($limit, $start = 0, $q = NULL) 
    {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id', $q);
		$this->db->or_like('nik', $q);
		$this->db->or_like('nama', $q);
		$this->db->or_like('kelas', $q);
		$this->db->or_like('alamat', $q);


		$this->db->limit($limit, $start);
	        return $this->db->get($this->table);
    }

    //cek nip dan password dosen
    function auth($username,$password){
        $query=$this->db->query("SELECT * FROM user WHERE unique_id='$username' AND password=MD5('$password') LIMIT 1");
        return $query;
    }
    function signup($username = 0){
		$this->load->helper('url');
		$cek = url_title($this->input_->post('username'), 'dash', TRUE);
		$data = array(
			'unique_id' => $this->input_->post('username'), 
			'username' => $this->input_->post('fname'), 
			'password' => md5($this->input_->post('password')),
			'level' => 2
		);
		if ($username == 0){
			return $this->db->insert('user', $data);
		} else {
			$url=base_url('');
            echo $this->session->set_flashdata('msg','Username sudah ada');
            redirect($url);
		}
	}

	private function _attributeLabels()
	{
		return[
			'nik'=> 'nik',
			'nama'=> 'nama',
			'kelas'=> 'kelas',
			'alamat'=> 'alamat'
		];
	}
	
	public function show_khstable()
	{
		return $this->db->get('download');
	}

    function Tampiltema1() 
    {
        $this->db->select('*');
		$this->db->from('tema1');
		$this->db->join('siswa','siswa.nik=tema1.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema1_2() 
    {
        $this->db->select('*');
		$this->db->from('tema1ket');
		$this->db->join('siswa','siswa.nik=tema1ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema2() 
    {
        $this->db->select('*');
		$this->db->from('tema2');
		$this->db->join('siswa','siswa.nik=tema2.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema2_2() 
    {
        $this->db->select('*');
		$this->db->from('tema2ket');
		$this->db->join('siswa','siswa.nik=tema2ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema3() 
    {
        $this->db->select('*');
		$this->db->from('tema3');
		$this->db->join('siswa','siswa.nik=tema3.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema3_2() 
    {
        $this->db->select('*');
		$this->db->from('tema3ket');
		$this->db->join('siswa','siswa.nik=tema3ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema4() 
    {
        $this->db->select('*');
		$this->db->from('tema4');
		$this->db->join('siswa','siswa.nik=tema4.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema4_2() 
    {
        $this->db->select('*');
		$this->db->from('tema4ket');
		$this->db->join('siswa','siswa.nik=tema4ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema5() 
    {
        $this->db->select('*');
		$this->db->from('tema5');
		$this->db->join('siswa','siswa.nik=tema5.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema5_2() 
    {
        $this->db->select('*');
		$this->db->from('tema5ket');
		$this->db->join('siswa','siswa.nik=tema5ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema6() 
    {
        $this->db->select('*');
		$this->db->from('tema6');
		$this->db->join('siswa','siswa.nik=tema6.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema6_2() 
    {
        $this->db->select('*');
		$this->db->from('tema6ket');
		$this->db->join('siswa','siswa.nik=tema6ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema7() 
    {
        $this->db->select('*');
		$this->db->from('tema7');
		$this->db->join('siswa','siswa.nik=tema7.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema7_2() 
    {
        $this->db->select('*');
		$this->db->from('tema7ket');
		$this->db->join('siswa','siswa.nik=tema7ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema8() 
    {
        $this->db->select('*');
		$this->db->from('tema8');
		$this->db->join('siswa','siswa.nik=tema8.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema8_2() 
    {
        $this->db->select('*');
		$this->db->from('tema8ket');
		$this->db->join('siswa','siswa.nik=tema8ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema9() 
    {
        $this->db->select('*');
		$this->db->from('tema9');
		$this->db->join('siswa','siswa.nik=tema9.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema9_2() 
    {
        $this->db->select('*');
		$this->db->from('tema9ket');
		$this->db->join('siswa','siswa.nik=tema9ket.nik');
		$query = $this->db->get();
		return $query->result();
    }
}