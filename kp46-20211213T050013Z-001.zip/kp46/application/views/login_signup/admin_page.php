<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	
	<p>Hi, <?php echo $this->session->userdata('ses_nama'); ?></p>
	<a href="<?php echo site_url('login/logout') ?>">Logout</a>
</body>
</html>