<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Ubah Tema 1 - System</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="<?php echo base_url('/assets/img/saluyu.jpg" type="image/x-icon')?>"/>

	<!-- Fonts and icons -->
	<script src="<?php echo base_url('/assets/js/plugin/webfont/webfont.min.js')?>"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?php echo base_url('/assets/css/fonts.min.css')?>']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" href="<?php echo base_url('/assets/css/atlantis.min.css')?>">
</head>
<body data-background-color="dark">
	<div class="wrapper">
		<div class="main-header">
			<!-- Logo Header -->
			<div class="logo-header" data-background-color="dark2">
				<img src="<?php echo base_url('/assets/img/saluyu.jpg')?>"class="avatar-img">
				<img src="<?php echo base_url('/assets/img/logo.jpg" alt="navbar brand')?>" class="navbar-brand">
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="icon-menu"></i>
					</span>
				</button>
				<button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
				<div class="nav-toggle">
					<button class="btn btn-toggle toggle-sidebar">
						<i class="icon-menu"></i>
					</button>
				</div>
			</div>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg" data-background-color="dark">
				<div class="container-fluid">
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
						<li class="nav-item toggle-nav-search hidden-caret">
							<a class="nav-link" data-toggle="collapse" href="#search-nav" role="button" aria-expanded="false" aria-controls="search-nav">
								<i class="fa fa-search"></i>
							</a>
						</li>
						<li class="nav-item dropdown hidden-caret">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
								<div class="avatar-sm">
									<img src="<?php echo base_url('/assets/img/saluyu.jpg')?>" alt="..." class="avatar-img rounded-circle">
								</div>
							</a>
							<ul class="dropdown-menu dropdown-user animated fadeIn">
								<div class="dropdown-user-scroll scrollbar-outer">
									<li>
										<div class="user-box">
											<div class="avatar-lg"><img src="<?php echo base_url('/assets/img/saluyu.jpg')?>" alt="image profile" class="avatar-img rounded"></div>
											<div class="u-text">
												<h4><?php echo $this->session->userdata('ses_nama'); ?></h4>
											</div>
										</div>
									</li>
									<li>
										<div class="dropdown-divider"></div>
										<a class="dropdown-item" href="<?php echo site_url('login/logout') ?>">Logout</a>
									</li>
								</div>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		<div class="sidebar sidebar-style-2" data-background-color="dark2">
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="info">
							<a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
								<span>
									<h2><?php echo $this->session->userdata('ses_nama'); ?></h2>
								</span>
							</a>
						</div>
					</div>
					<ul class="nav nav-primary">
						<li class="nav-item active">
							<a href="<?php echo site_url('admin/v_admin') ?>">
								<i class="fas fa-home"></i>
								<p>Dashboard</p>
							</a>
						</li>
						<li class="nav-section">
							<span class="sidebar-mini-icon">
								<i class="fa fa-ellipsis-h"></i>
							</span>
							<h4 class="text-section">Components</h4>
						</li>			
						<li class="nav-item">
							<a data-toggle="collapse" href="#forms">
								<i class="fas fa-book"></i>
								<p>Data Siswa</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="forms">
								<ul class="nav nav-collapse">
									<li>
										<a href="<?php echo site_url('admin/Data_siswaView')?>">
											<span class="sub-item">Daftar Siswa</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('pelajaran/PelajaranView')?>">
											<span class="sub-item">Daftar Pelajaran</span>
										</a>
									</li>
								</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-toggle="collapse" href="#sidebarLayouts">
								<i class="fas fa-book"></i>
								<p>Semester 1</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="sidebarLayouts">
								<ul class="nav nav-collapse">
									<li>
										<a href="<?php echo site_url('nilai/Tema1_View')?>">
											<span class="sub-item">Tema 1</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('nilai/Tema2_View')?>">
											<span class="sub-item">Tema 2</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('nilai/Tema3_View')?>">
											<span class="sub-item">Tema 3</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('nilai/Tema4_View')?>">
											<span class="sub-item">Tema 4</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('nilai/Tema5_View')?>">
											<span class="sub-item">Tema 5</span>
										</a>
									</li>
								</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-toggle="collapse" href="#tables">
								<i class="fas fa-book"></i>
								<p>Semester 2</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="tables">
								<ul class="nav nav-collapse">
									<li>
										<a href="<?php echo site_url('nilai/Tema6_View')?>">
											<span class="sub-item">Tema 6</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('nilai/Tema7_View')?>">
											<span class="sub-item">Tema 7</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('nilai/Tema8_View')?>">
											<span class="sub-item">Tema 8</span>
										</a>
									</li>
									<li>
										<a href="<?php echo site_url('nilai/Tema9_View')?>">
											<span class="sub-item">Tema 9</span>
										</a>
									</li>
								</ul>
							</div>
						</li>	
					</ul>
				</div>
			</div>
		</div>
		<!-- End Sidebar -->

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Profile</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?php echo site_url('admin/v_admin') ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="<?php echo site_url('nilai/Tema1_View')?>">Tema 1</a>
							</li>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Kompetisi Dasar (KD)</h4>
								</div>
								<div class="card-body">
									<div class="card-body">
										<form action="<?php echo site_url('nilai/edit_Tema1') ?>" method ="post">
										<input type="submit" value="Simpan">
										<input type="button" value="Batal" onclick="javascript:history.go(-1);"/>
										<?php
											$no=1;
												foreach ($hasil1 as $rw)
													{ ?>
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" border="1" >
											<thead>
												<tr>
										            <th rowspan="2">No</th>
										            <th rowspan="2">NIK</th>
										            <th rowspan="2">Nama</th>
										        </tr>
										    </thead>
										    <tbody>
												<tr>
													<td><?php echo $no++ ?></td>
														<input type="hidden" class="form-control" name="id" value="<?php echo $rw->id ?>">
														<td>
															<?php echo $rw->nik; ?>
														</td>
														<td>
															<?php echo $rw->nama; ?>
														</td>
												</tr>
										    </tbody>
										    <thead>
										        <tr>
										            <th colspan="3">Tema 1</th>
										        </tr>
										        <tr>
										            <th>1</th>
										            <th>2</th>
										            <th>3</th>
										        </tr>
											</thead>
											<tbody>
												<tr>
													<td>
														<input name="a" value="<?php echo $rw->a; ?>">
													</td>
													<td>
														<input name="b" value="<?php echo $rw->b; ?>">
													</td>
													<td>
														<input name="c" value="<?php echo $rw->c; ?>">
													</td>
												</tr>
											</tbody>
										    <thead>
										        <tr>
										            <th colspan="3">Tema 2</th>
										        </tr>
										        <tr>
										            <th>1</th>
										            <th>2</th>
										            <th>3</th>
										        </tr>
											</thead>
											<tbody>
												<tr>
													<td>
														<input name="d" value="<?php echo $rw->d; ?>">
													</td>
													<td>
														<input name="e" value="<?php echo $rw->e; ?>">
													</td>
														<td>
														<input name="f" value="<?php echo $rw->f; ?>">
													</td>
												</tr>
											</tbody>
										    <thead>
										        <tr>
										            <th colspan="3">Tema 3</th>
										        </tr>
										        <tr>
										            <th>1</th>
										            <th>2</th>
										            <th>3</th>
										        </tr>
											</thead>
											<tbody>
												<tr>
													<td>
														<input name="g" value="<?php echo $rw->g; ?>">
													</td>
													<td>
														<input name="h" value="<?php echo $rw->h; ?>">
													</td>
													<td>
														<input name="i" value="<?php echo $rw->i; ?>">
													</td>
												</tr>
											</tbody>
											<thead>
										        <tr>
										            <th>UTS</th>
										            <th>UAS</th>
										        </tr>
											</thead>
											<tbody>
												<tr>	
													<td>
														<input name="j" value="<?php echo $rw->j; ?>">
													</td>
													<td>
														<input name="k" value="<?php echo $rw->k; ?>">
													</td>
												</tr>
											</tbody>
											<?php }
										            ?>
										</table>
									</div>
								</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<div class="copyright ml-auto">
						2021, made with <i class="fa fa-heart heart text-danger"></i> by <a href="https://www.instagram.com/gps018">Gita Purnamasari</a>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
	<!--   Core JS Files   -->
	<script src="<?php echo base_url('/assets/js/core/jquery.3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('/assets/js/core/popper.min.js')?>"></script>
	<script src="<?php echo base_url('/assets/js/core/bootstrap.min.js')?>"></script>

	<!-- jQuery UI -->
	<script src="<?php echo base_url('/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')?>"></script>
	<script src="<?php echo base_url('/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js')?>"></script>

	<!-- jQuery Scrollbar -->
	<script src="<?php echo base_url('/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')?>"></script>


	<!-- Chart JS -->
	<script src="<?php echo base_url('/assets/js/plugin/chart.js/chart.min.js')?>"></script>

	<!-- jQuery Sparkline -->
	<script src="<?php echo base_url('/assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js')?>"></script>

	<!-- Chart Circle -->
	<script src="<?php echo base_url('/assets/js/plugin/chart-circle/circles.min.js')?>"></script>

	<!-- Datatables -->
	<script src="<?php echo base_url('/assets/js/plugin/datatables/datatables.min.js')?>"></script>

	<!-- Bootstrap Notify -->
	<script src="<?php echo base_url('/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js')?>"></script>

	<!-- jQuery Vector Maps -->
	<script src="<?php echo base_url('/assets/js/plugin/jqvmap/jquery.vmap.min.js')?>"></script>
	<script src="<?php echo base_url('/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js')?>"></script>

	<!-- Sweet Alert -->
	<script src="<?php echo base_url('/assets/js/plugin/sweetalert/sweetalert.min.js')?>"></script>

	<!-- Atlantis JS -->
	<script src="<?php echo base_url('/assets/js/atlantis.min.js')?>"></script>
</body>
</html>