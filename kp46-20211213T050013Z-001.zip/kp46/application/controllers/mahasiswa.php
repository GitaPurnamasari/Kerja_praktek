<?php
class mahasiswa extends CI_Controller
{
	function __construct()
	{
        parent::__construct();      
        $this->load->model('mahasiswa_model');
        $this->load->library('form_validation');
        /*$this->model = $this->mahasiswa_model;
        $this->load->database();
        $this->load->helper('url');*/
    }

    function index()
    {
        $data['user'] = $this->mahasiswa_model->tampil_data()->result();
    	$this->load->view('mahasiswa/index');
        $this->load->model('mahasiswa_model');
    }

    public function laporan_pdf($id_nilai)
    {

        $data['pdf'] = $this->pdf_model->print_database($id_nilai);
        $this->load->library('pdf');

        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->filename = "Nilai.pdf";
        $this->pdf->load_view('mahasiswa/Dokumen Mahasiswa/vpdf', $data);
    }

    function Data_SiswaView()
    {
        $data['siswa'] = $this->mahasiswa_model->show_khstable()->result();
        $this->load->view('mahasiswa/Dokumen Mahasiswa/DataSiswa');
    }

    public function add()
    {
        $this->form_validation->set_rules('nim','nim','required');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('jurusan','jurusan','required');
        $this->form_validation->set_rules('keterangan','keterangan','required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('error',"Data Gagal Di Tambahkan");
            redirect('mahasiswa/DataIndukView');
        }
        else
        {
                $nim  = $this->input->post('nim',TRUE);
                $nama = $this->input->post('nama',TRUE);
                $jurusan = $this->input->post('jurusan',TRUE);
                $keterangan = $this->input->post('keterangan',TRUE);
                $data = array(
                    'nim'=>$nim, 
                    'nama'=>$nama, 
                    'jurusan'=>$jurusan, 
                    'keterangan'=>$keterangan
                    );

                $insert = $this->db->insert('pengajuan',$data);
                $this->session->set_flashdata('sukses','Data Berhasil Di Tambahkan');
                redirect('mahasiswa/SuratPengajuanView');
        }         
    }

    function NilaiView()
    {
        $data['user'] = $this->mahasiswa_model->show_khstable()->result();
        $this->load->view('mahasiswa/Dokumen Mahasiswa/nilai', $data);
    }

    function DownloadView()
    {
        $data['user'] = $this->mahasiswa_model->show_khstable()->result();
        $this->load->view('mahasiswa/Dokumen Mahasiswa/Download', $data);
    }
}