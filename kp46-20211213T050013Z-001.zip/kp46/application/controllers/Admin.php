<?php
class Admin extends CI_Controller
{
    function __construct()
    {
        parent::__construct();      
        $this->load->model('admin_model');
        $this->load->model('Admin_model');
        $this->load->model('pdf_model');
        $this->model = $this->admin_model;
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('form');
        $this->load->helper('text');
    }

    function v_admin()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'admin/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'admin/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'admin/index.html';
            $config['first_url'] = base_url() . 'admin/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->admin_model->total_rows($q);
        $mhs = $this->admin_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'model' => $mhs,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('admin/v_admin', $data);
    }
    function Data_siswaView()
    {
        $rows = $this->model->read();
        $this->load->view('admin/Dokumen Admin/Data_siswa', ['rows' => $rows]);
    }

    public function TambahView()
    {
        $rows = $this->model->read();
        $this->load->view('admin/Dokumen Admin/tambah', ['rows' => $rows]);
    }

    public function add()
    {
        $this->load->helper('form');         
        $this->load->library('form_validation');
        $this->load->library('form_validation');//yg ini taruh di cunstructor
        $this->form_validation->set_rules('nik', 'nik', 'required|trim|is_unique[siswa.nik]',['is_unique' => 'nik ini sudah ada !']);

       if($this->form_validation->run() == false)
       {
            $this->load->view('admin/Dokumen Admin/Tambah');
       }else
        {
            $id = $this->input->post('id');
            $nik  = $this->input->post('nik');
            $nama = $this->input->post('nama');
            $kelas = $this->input->post('kelas');
            $alamat = $this->input->post('alamat');

            $data = [
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'nama'=>$nama, 
                'kelas'=>$kelas, 
                'alamat'=>$alamat
            ];
            $data_nilai = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema1 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema2 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema3 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema4 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema5 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema6 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema7 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema8 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema9 = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema1ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'Nama' => $nama];
            $tema2ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema3ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema4ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema5ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema6ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema7ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema8ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];
            $tema9ket = ['nik' => htmlspecialchars($this->input->post('nik', true)),'nama' => $nama];

            $insert = $this->db->insert('siswa',$data);
            $insert = $this->db->insert('nilai',$data_nilai);
            $insert = $this->db->insert('tema1',$tema1);
            $insert = $this->db->insert('tema2',$tema2);
            $insert = $this->db->insert('tema3',$tema3);
            $insert = $this->db->insert('tema4',$tema4);
            $insert = $this->db->insert('tema5',$tema5);
            $insert = $this->db->insert('tema6',$tema6);
            $insert = $this->db->insert('tema7',$tema7);
            $insert = $this->db->insert('tema8',$tema8);
            $insert = $this->db->insert('tema9',$tema9);
            $insert = $this->db->insert('tema1ket',$tema1ket);
            $insert = $this->db->insert('tema2ket',$tema2ket);
            $insert = $this->db->insert('tema3ket',$tema3ket);
            $insert = $this->db->insert('tema4ket',$tema4ket);
            $insert = $this->db->insert('tema5ket',$tema5ket);
            $insert = $this->db->insert('tema6ket',$tema6ket);
            $insert = $this->db->insert('tema7ket',$tema7ket);
            $insert = $this->db->insert('tema8ket',$tema8ket);
            $insert = $this->db->insert('tema9ket',$tema9ket);
            $this->session->set_flashdata('sukses','Data Berhasil Di Tambahkan');
            redirect('admin/Data_siswaView');
        }
    }

    public function Ubah_SiswaView($id)
    {
        $where = array('id' => $id);
        $data['siswa'] = $this->model->edit_siswa($where,'siswa')->result();
        $this->load->view('admin/Dokumen Admin/Ubah_Siswa',$data);
    }

    public function update()
    {
        $id = $this->input->post('id');
        $nik = $this->input->post('nik');
        $nama = $this->input->post('Nama');
        $kelas = $this->input->post('kelas');
        $alamat = $this->input->post('alamat');
        $data = array(
            'nik' => $nik,
            'Nama' => $nama,
            'kelas' => $kelas,
            'alamat' => $alamat
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_data($where,$data,'siswa');
        redirect('admin/Data_siswaView');
    }

    public function delete($id) 
    {
        $where = array('id' => $id);
        $this->model->hapus_data($where,'siswa');
        redirect('admin/Data_siswaView');
    }

    public function DeleteAll()
    {
        $data['hapus'] = $this->model->hapus_all()->result();
        $this->model->DeleteAll();
        $this->load->view('admin/v_admin', $data);
    }

    public function laporan_pdf()
    {
        $this->load->model('pdf_model');
        $data['siswa'] = $this->pdf_model->siswa();
        $data['tema1'] = $this->pdf_model->tema1();
        $data['tema1ket'] = $this->pdf_model->tema1ket();
        $data['tema2'] = $this->pdf_model->tema2();
        $data['tema2ket'] = $this->pdf_model->tema3ket();
        $data['tema3'] = $this->pdf_model->tema3();
        $data['tema3ket'] = $this->pdf_model->tema3ket();
        $data['tema4'] = $this->pdf_model->tema4();
        $data['tema4ket'] = $this->pdf_model->tema4ket();
        $data['tema5'] = $this->pdf_model->tema5();
        $data['tema5ket'] = $this->pdf_model->tema5ket();
        $data['tema6'] = $this->pdf_model->tema6();
        $data['tema6ket'] = $this->pdf_model->tema6ket();
        $data['tema7'] = $this->pdf_model->tema7();
        $data['tema7ket'] = $this->pdf_model->tema7ket();
        $data['tema8'] = $this->pdf_model->tema8();
        $data['tema8ket'] = $this->pdf_model->tema8ket();
        $data['tema9'] = $this->pdf_model->tema9();
        $data['tema9ket'] = $this->pdf_model->tema9ket();
        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'landscape');
        $this->pdf->filename = "Data Rekap.pdf";
        $this->pdf->load_view('admin/Dokumen Admin/vpdf', $data);
    }
}