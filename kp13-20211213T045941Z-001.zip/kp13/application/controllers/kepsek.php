<?php
class kepsek extends CI_Controller
{
    function __construct()
    {
        parent::__construct();      
        $this->load->model('kepsel_model');
        $this->load->model('pdf_model');
        $this->model = $this->kepsel_model;
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('form');
        $this->load->helper('text');
    }

    function v_admin3()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'kepsek/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'kepsek/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'kepsek/index.html';
            $config['first_url'] = base_url() . 'kepsek/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->kepsel_model->total_rows($q);
        $mhs = $this->kepsel_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'model' => $mhs,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('kepsek/v_admin3', $data);
    }

    public function PelajaranView()
    {
        $rows = $this->model->read();
        $this->load->view('kepsek/Dokumen kepsek/pelajaran', ['rows' => $rows]);
    }

    function Data_siswaView()
    {
        $rows = $this->model->read();
        $this->load->view('kepsek/Dokumen kepsek/Data_siswa', ['rows' => $rows]);
    }

    public function Tema1_View()
    { 
        $rows = $this->model->read();
        $data['hasil1']=$this->model->Tampiltema1();
        $data['hasil2']=$this->model->Tampiltema1_2();
        $this->load->view('kepsek/Tema/Tema_1',$data);
    }

    public function Tema2_View()
    {
        $rows = $this->model->read();
        $data['hasil1']=$this->model->Tampiltema2();
        $data['hasil2']=$this->model->Tampiltema2_2();  
        $this->load->view('kepsek/Tema/Tema_2',$data);
    }

    public function Tema3_View()
    {
        $rows = $this->model->read();
        $data['hasil1']=$this->model->Tampiltema3();
        $data['hasil2']=$this->model->Tampiltema3_2();
        $this->load->view('kepsek/Tema/Tema_3',$data);
    }

    public function Tema4_View()
    {
        $rows = $this->model->read();
        $data['hasil1']=$this->model->Tampiltema4();
        $data['hasil2']=$this->model->Tampiltema4_2();
        $this->load->view('kepsek/Tema/Tema_4',$data);
    }

    public function Tema5_View()
    {
        $rows = $this->model->read();
        $data['hasil1']=$this->model->Tampiltema5();
        $data['hasil2']=$this->model->Tampiltema5_2();
        $this->load->view('kepsek/Tema/Tema_5',$data);
    }

    public function Tema6_View()
    {
        $data['hasil1']=$this->model->Tampiltema6();
        $data['hasil2']=$this->model->Tampiltema6_2();
        $this->load->view('kepsek/Tema/Tema_6',$data);
    }

    public function Tema7_View()
    {
        $data['hasil1']=$this->model->Tampiltema7();
        $data['hasil2']=$this->model->Tampiltema7_2();
        $this->load->view('kepsek/Tema/Tema_7',$data);
    }

    public function Tema8_View()
    {
        $data['hasil1']=$this->model->Tampiltema8();
        $data['hasil2']=$this->model->Tampiltema8_2();
        $this->load->view('kepsek/Tema/Tema_8',$data);
    }

    public function laporan_pdf()
    {
        $this->load->model('pdf_model');
        $data['siswa'] = $this->pdf_model->siswa();
        $data['tema1'] = $this->pdf_model->tema1();
        $data['tema1ket'] = $this->pdf_model->tema1ket();
        $data['tema2'] = $this->pdf_model->tema2();
        $data['tema2ket'] = $this->pdf_model->tema3ket();
        $data['tema3'] = $this->pdf_model->tema3();
        $data['tema3ket'] = $this->pdf_model->tema3ket();
        $data['tema4'] = $this->pdf_model->tema4();
        $data['tema4ket'] = $this->pdf_model->tema4ket();
        $data['tema5'] = $this->pdf_model->tema5();
        $data['tema5ket'] = $this->pdf_model->tema5ket();
        $data['tema6'] = $this->pdf_model->tema6();
        $data['tema6ket'] = $this->pdf_model->tema6ket();
        $data['tema7'] = $this->pdf_model->tema7();
        $data['tema7ket'] = $this->pdf_model->tema7ket();
        $data['tema8'] = $this->pdf_model->tema8();
        $data['tema8ket'] = $this->pdf_model->tema8ket();
        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'landscape');
        $this->pdf->filename = "Data Rekap.pdf";
        $this->pdf->load_view('kepsek/Dokumen kepsek/vpdf', $data);
    }
}