<?php
class pelajaran extends CI_Controller
{
    function __construct()
    {
        parent::__construct();      
        $this->load->model('pelajaran_model');
        $this->load->model('pdf_model');
        $this->model = $this->pelajaran_model;
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('form');
        $this->load->helper('text');
    }

    public function PelajaranView()
    {
        $rows = $this->model->read();
        $this->load->view('admin/Dokumen admin/pelajaran', ['rows' => $rows]);
    }

    public function Tambah_pelajaranView()
    {
        $rows = $this->model->read();
        $this->load->view('admin/Dokumen admin/tambah_Pelajaran', ['rows' => $rows]);
    }

    public function Tambah_Pelajaran_add()
    {
        $this->form_validation->set_rules('kode', 'kode', 'required');
        $this->form_validation->set_rules('pelajaran', 'pelajaran', 'required');
        $this->form_validation->set_rules('guru', 'guru', 'required');
        
        $kode = $this->input->post('kode');
        $pelajaran  = $this->input->post('pelajaran');
        $guru = $this->input->post('guru');
        $data = array(

            'kode' => $kode,
            'pelajaran' =>$pelajaran,
            'guru' => $guru
            );
        $insert = $this->db->insert('pelajaran',$data);
        $this->session->set_flashdata('sukses','Data Berhasil Di Tambahkan');
        redirect('pelajaran/PelajaranView');      
    }
    
    public function Ubah_PelajaranView($id)
    {
        $this->form_validation->set_rules('kode', 'kode', 'required');
        $this->form_validation->set_rules('pelajaran', 'pelajaran', 'required');
        $this->form_validation->set_rules('guru', 'guru', 'required');
        
        $where = array('id' => $id);
        $data['pelajaran'] = $this->model->edit_data($where,'pelajaran')->result();
        $this->load->view('admin/Dokumen admin/Ubah_Pelajaran',$data);
    }

    public function update_pelajaran()
    {
        $id = $this->input->post('id');
        $kode = $this->input->post('kode');
        $pelajaran = $this->input->post('pelajaran');
        $guru = $this->input->post('guru');
        $data = array(
            'kode' => $kode,
            'pelajaran' => $pelajaran,
            'guru' => $guru
        );
     
        $where = array(
            'id' => $id
        );
 
        $this->model->update_data($where,$data,'pelajaran');
        redirect('pelajaran/PelajaranView');
    }

    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) 
        {
            $this->update($this->input->post('id', TRUE));
        } else 
        {
            $data = array(
                'nik' => $this->input->post('nik',TRUE),
                'nama' => $this->input->post('nama',TRUE),
                'kelas' => $this->input->post('kelas',TRUE),
                'alamat' => $this->input->post('alamat',TRUE),
                'id' => $this->input->post('id',TRUE),
                );

            $this->pelajaran_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('pelajaran'));
        }
    }

    public function delete($id) 
    {
        $where = array('id' => $id);
        $this->model->hapus_data($where,'siswa');
        redirect('pelajaran/Data_siswaView');
    }

    public function delete_pelajaran($id) 
    {
        $where = array('id' => $id);
        $this->model->hapus_data($where,'pelajaran');
        redirect('pelajaran/PelajaranView');
    }

    public function _rules() 
    {
    $this->form_validation->set_rules('nik', 'nik', 'trim|required');
    $this->form_validation->set_rules('nama', 'nama', 'trim|required');
    $this->form_validation->set_rules('kelas', 'kelas', 'trim|required');
    $this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
    $this->form_validation->set_rules('link_surat', 'link_surat', 'trim|required');

    $this->form_validation->set_rules('nik', 'nik', 'trim|required');

    $this->form_validation->set_rules('nik', 'nik', 'trim');
    $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }
}