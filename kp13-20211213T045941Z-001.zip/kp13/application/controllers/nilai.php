<?php
class nilai extends CI_Controller
{
    function __construct()
    {
        parent::__construct();      
        $this->load->model('nilai_model');
        $this->load->model('pdf_model');
        $this->model = $this->nilai_model;
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('form');
        $this->load->helper('text');
    }

    public function Tema1_View()
    {
        $data['hasil1']=$this->model->Tampiltema1();
        $data['hasil2']=$this->model->Tampiltema1_2();
        $this->load->view('admin/Tema/Tema_1',$data);
    }

    public function Ubah_Tema1View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema1($where,'tema1')->result();
        $this->load->view('admin/Tema/Ubah_Tema1',$data);
    }

    public function edit_Tema1()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema1($where,$data,'tema1');
        redirect('nilai/Tema1_View');
    }

    public function Ubah_Tema1ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema1ket($where,'tema1ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema1ket',$data);
    }

    public function edit_Tema1ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema1ket($where,$data,'tema1ket');
        redirect('nilai/Tema1_View');
    }

    public function Tema2_View()
    {
        $data['hasil1']=$this->model->Tampiltema2();
        $data['hasil2']=$this->model->Tampiltema2_2();
        $this->load->view('admin/Tema/Tema_2',$data);
    }

    public function Ubah_Tema2View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema2($where,'tema2')->result();
        $this->load->view('admin/Tema/Ubah_Tema2',$data);
    }

    public function edit_Tema2()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema2($where,$data,'tema2');
        redirect('nilai/Tema2_View');
    }

    public function Ubah_Tema2ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema2ket($where,'tema2ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema2ket',$data);
    }

    public function edit_Tema2ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema2ket($where,$data,'tema2ket');
        redirect('nilai/Tema2_View');
    }

    public function Tema3_View()
    {
        $data['hasil1']=$this->model->Tampiltema3();
        $data['hasil2']=$this->model->Tampiltema3_2();
        $this->load->view('admin/Tema/Tema_3',$data);
    }

    public function Ubah_Tema3View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema3($where,'tema3')->result();
        $this->load->view('admin/Tema/Ubah_Tema3',$data);
    }

    public function edit_Tema3()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema3($where,$data,'tema3');
        redirect('nilai/Tema3_View');
    }

    public function Ubah_Tema3ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema3ket($where,'tema3ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema3ket',$data);
    }

    public function edit_Tema3ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema3ket($where,$data,'tema3ket');
        redirect('nilai/Tema3_View');
    }

    public function Tema4_View()
    {
        $data['hasil1']=$this->model->Tampiltema4();
        $data['hasil2']=$this->model->Tampiltema4_2();
        $this->load->view('admin/Tema/Tema_4',$data);
    }

    public function Ubah_Tema4View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema4($where,'tema4')->result();
        $this->load->view('admin/Tema/Ubah_Tema4',$data);
    }

    public function edit_Tema4()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema4($where,$data,'tema4');
        redirect('nilai/Tema4_View');
    }

    public function Ubah_Tema4ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema4ket($where,'tema4ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema4ket',$data);
    }

    public function edit_Tema4ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema4ket($where,$data,'tema4ket');
        redirect('nilai/Tema4_View');
    }

    public function Tema5_View()
    {
        $data['hasil1']=$this->model->Tampiltema5();
        $data['hasil2']=$this->model->Tampiltema5_2();
        $this->load->view('admin/Tema/Tema_5',$data);
    }

    public function Ubah_Tema5View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema5($where,'tema5')->result();
        $this->load->view('admin/Tema/Ubah_Tema5',$data);
    }

    public function edit_Tema5()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema5($where,$data,'tema5');
        redirect('nilai/Tema5_View');
    }

    public function Ubah_Tema5ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema5ket($where,'tema5ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema5ket',$data);
    }

    public function edit_Tema5ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema5ket($where,$data,'tema5ket');
        redirect('nilai/Tema5_View');
    }

    public function Tema6_View()
    {
        $data['hasil1']=$this->model->Tampiltema6();
        $data['hasil2']=$this->model->Tampiltema6_2();
        $this->load->view('admin/Tema/Tema_6',$data);
    }

    public function Ubah_Tema6View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema6($where,'tema6')->result();
        $this->load->view('admin/Tema/Ubah_Tema6',$data);
    }

    public function edit_Tema6()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema6($where,$data,'tema6');
        redirect('nilai/Tema6_View');
    }

    public function Ubah_Tema6ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema6ket($where,'tema6ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema6ket',$data);
    }

    public function edit_Tema6ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema6ket($where,$data,'tema6ket');
        redirect('nilai/Tema6_View');
    }

    public function Tema7_View()
    {
        $data['hasil1']=$this->model->Tampiltema7();
        $data['hasil2']=$this->model->Tampiltema7_2();
        $this->load->view('admin/Tema/Tema_7',$data);
    }

    public function Ubah_Tema7View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema7($where,'tema7')->result();
        $this->load->view('admin/Tema/Ubah_Tema7',$data);
    }

    public function edit_Tema7()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema7($where,$data,'tema7');
        redirect('nilai/Tema7_View');
    }

    public function Ubah_Tema7ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema7ket($where,'tema7ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema7ket',$data);
    }

    public function edit_Tema7ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema7ket($where,$data,'tema7ket');
        redirect('nilai/Tema7_View');
    }

    public function Tema8_View()
    {
        $data['hasil1']=$this->model->Tampiltema8();
        $data['hasil2']=$this->model->Tampiltema8_2();
        $this->load->view('admin/Tema/Tema_8',$data);
    }

    public function Ubah_Tema8View($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil1'] = $this->model->edit_Tema8($where,'tema8')->result();
        $this->load->view('admin/Tema/Ubah_Tema8',$data);
    }

    public function edit_Tema8()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema8($where,$data,'tema8');
        redirect('nilai/Tema8_View');
    }

    public function Ubah_Tema8ketView($nik)
    {
        $where = array('nik' => $nik);
        $data['hasil2'] = $this->model->edit_Tema8ket($where,'tema8ket')->result();
        $this->load->view('admin/Tema/Ubah_Tema8ket',$data);
    }

    public function edit_Tema8ket()
    {   
        $id = $this->input->post('id');
        $a= $this->input->post('a');
        $b= $this->input->post('b');
        $c= $this->input->post('c');
        $d= $this->input->post('d');
        $e= $this->input->post('e');
        $f= $this->input->post('f');
        $g= $this->input->post('g');
        $h= $this->input->post('h');
        $i= $this->input->post('i');
        $j= $this->input->post('j');
        $k= $this->input->post('k');
        $l= $this->input->post('l');
        $m= $this->input->post('m');
        $n= $this->input->post('n');
        $o= $this->input->post('o');
        $p= $this->input->post('p');
        $q= $this->input->post('q');
        $r= $this->input->post('r');
        $s= $this->input->post('s');
        $t= $this->input->post('t');
        $u= $this->input->post('u');
        $v= $this->input->post('v');
        $w= $this->input->post('w');
        $x= $this->input->post('x');
        $y= $this->input->post('y');
        $z= $this->input->post('z');
        $data = array(
            'a' => $a,
            'b' => $b,
            'c' => $c,
            'd' => $d,
            'e' => $e,
            'f' => $f,
            'g' => $g,
            'h' => $h,
            'i' => $i,
            'j' => $j,
            'k' => $k,
            'l' => $l,
            'm' => $m,
            'n' => $n,
            'o' => $o,
            'p' => $p,
            'q' => $q,
            'r' => $r,
            's' => $s,
            't' => $t,
            'u' => $u,
            'v' => $v,
            'w' => $w,
            'x' => $x,
            'y' => $y,
            'z' => $z
        );
     
        $where = array(
            'id' => $id
        );
        $this->model->update_tema8ket($where,$data,'tema8ket');
        redirect('nilai/Tema8_View');
    }
}