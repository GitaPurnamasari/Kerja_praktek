<?php
class Login extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('login_model');
    }
 
    function index(){
        $this->load->view('login_signup/Login');
    }
 
    function auth(){
        $username=htmlspecialchars($this->input->post('username',TRUE),ENT_QUOTES);
        $password=htmlspecialchars($this->input->post('password',TRUE),ENT_QUOTES);
 
        $cek=$this->login_model->auth($username,$password);
 
        if($cek->num_rows() > 0)
        {
                $data=$cek->row_array();
                $this->session->set_userdata('masuk',TRUE);
                 if($data['level']=='1'){ //Akses Walikelas 1-3
                    $this->session->set_userdata('akses','1');
                    $this->session->set_userdata('ses_id',$data['unique_id']);
                    $this->session->set_userdata('ses_nama',$data['username']);
                    $this->session->set_userdata('ses_user',$data['level']);
                    $this->load->view('admin/v_admin');
 /*
                 }elseif($data['level']=='2'){ //Akses Walikelas 4-6
                    $this->session->set_userdata('akses','2');
                    $this->session->set_userdata('ses_id',$data['unique_id']);
                    $this->session->set_userdata('ses_nama',$data['username']);
                    $this->session->set_userdata('ses_user',$data['level']);
                    $this->load->view('admin2/v_admin2');*/

                 }elseif($data['level']=='3'){ //Akses Kepala Sekolah
                    $this->session->set_userdata('akses','3');
                    $this->session->set_userdata('ses_id',$data['unique_id']);
                    $this->session->set_userdata('ses_nama',$data['username']);
                    $this->load->view('kepsek/v_admin3');

                 }
        }else{  
            $this->load->view('login_signup/Login');
        }
 
    }
 
    function logout(){
        $this->session->sess_destroy();
        $url=base_url('');
        redirect($url);
    }

    function register(){
    	$this->load->view('login_signup/Signup');
    }

    function signup(){
    	$this->load->helper('form');         
		$this->load->library('form_validation');           
		$data['title'] = '';           
		$this->form_validation->set_rules('username', 'username', 'required');         
		$this->form_validation->set_rules('fname', 'fname', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		
		if ($this->form_validation->run() === FALSE){                        
			$this->load->view('login_signup/Signup');                        
		}else{             
			$this->login_model->signup();                          
			$this->load->view('login_signup/Login');                
			//
			+redirect( base_url().'index.php/login');     			
		}  
    }
}