<h2><center>Data Siswa SD Negeri 234 Saluyu</center></h2>
</br>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th>No</th>
		<th>NIK</th>
		<th>Nama</th>
		<th>Kelas</th>
		<th>Alamat</th>
	</tr>
	<?php 
	$no = 1;
	foreach($siswa as $rw)
	{
		?>
		<tr>

			<td><?php echo $no++ ?></td>
			<td><?php echo $rw->nik ?></td>
			<td><?php echo $rw->Nama ?></td>
			<td><?php echo $rw->kelas ?></td>
			<td><?php echo $rw->alamat ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br></br>
<h1>Semester 1</h1>
</br>
</br>
<h2><center>Rekap Siswa Tema 1 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema1 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 1 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema1ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 2 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema2 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 2 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema2ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 3 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema3 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 3 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema3ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
</br>
<h2><center>Rekap Siswa Tema 4 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema4 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 4 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema4ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br><h1>Semester 2</h1>
</br>
</br>
<h2><center>Rekap Siswa Tema 5 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema5 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 5 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema5ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 6 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema6 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 6 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema6ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 7 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema7 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 7 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema7ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
</br>
<h2><center>Rekap Siswa Tema 8 Pengetahuan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema8 as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>
<h2><center>Rekap Siswa Tema 8 Keterampilan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">NIK</th>
		<th rowspan="2">Nama</th>
		<th colspan="6">Sub Tema 1</th>
		<th colspan="6">Sub Tema 2</th>
		<th colspan="6">Sub Tema 3</th>
		<th colspan="6">Sub Tema 4</th>
		<th rowspan="2">UTS</th>
		<th rowspan="2">UAS</th>
	</tr>
	<tr>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
		<th>1</th>
		<th>2</th>
		<th>3</th>
		<th>4</th>
		<th>5</th>
		<th>6</th>
	</tr>
	<?php 
	$no = 1;
	foreach($tema8ket as $rw)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $rw->nik; ?></td>
			<td><?php echo $rw->Nama; ?></td>
			<td><?php echo $rw->a; ?></td>
			<td><?php echo $rw->b; ?></td>
			<td><?php echo $rw->c; ?></td>
			<td><?php echo $rw->d; ?></td>
			<td><?php echo $rw->e; ?></td>
			<td><?php echo $rw->f; ?></td>
			<td><?php echo $rw->g; ?></td>
			<td><?php echo $rw->h; ?></td>
			<td><?php echo $rw->i; ?></td>
			<td><?php echo $rw->j; ?></td>
			<td><?php echo $rw->k; ?></td>
			<td><?php echo $rw->l; ?></td>
			<td><?php echo $rw->m; ?></td>
			<td><?php echo $rw->n; ?></td>
			<td><?php echo $rw->o; ?></td>
			<td><?php echo $rw->p; ?></td>
			<td><?php echo $rw->q; ?></td>
			<td><?php echo $rw->r; ?></td>
			<td><?php echo $rw->s; ?></td>
			<td><?php echo $rw->t; ?></td>
			<td><?php echo $rw->u; ?></td>
			<td><?php echo $rw->v; ?></td>
			<td><?php echo $rw->w; ?></td>
			<td><?php echo $rw->x; ?></td>
			<td><?php echo $rw->y; ?></td>
			<td><?php echo $rw->z; ?></td>
		</tr>
		<?php
	}
	?>
</table>
</br>