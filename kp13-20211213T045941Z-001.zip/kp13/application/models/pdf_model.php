<?php
/**
 * 
 */
class pdf_model extends CI_Model
{
	function siswa()
	{
		$this->db->from('siswa');
		$query = $this->db->get();
		return$query->result();
	}

	function tema1()
	{
		$this->db->select('*');
		$this->db->from('tema1');
		$this->db->join('siswa','siswa.nik=tema1.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema1ket()
	{
		$this->db->select('*');
		$this->db->from('tema1ket');
		$this->db->join('siswa','siswa.nik=tema1ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}


	function tema2()
	{
		$this->db->select('*');
		$this->db->from('tema2');
		$this->db->join('siswa','siswa.nik=tema2.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema2ket()
	{
		$this->db->select('*');
		$this->db->from('tema2ket');
		$this->db->join('siswa','siswa.nik=tema2ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}

	function tema3()
	{
		$this->db->select('*');
		$this->db->from('tema3');
		$this->db->join('siswa','siswa.nik=tema3.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema3ket()
	{
		$this->db->select('*');
		$this->db->from('tema3ket');
		$this->db->join('siswa','siswa.nik=tema3ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}

	function tema4()
	{
		$this->db->select('*');
		$this->db->from('tema4');
		$this->db->join('siswa','siswa.nik=tema4.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema4ket()
	{
		$this->db->select('*');
		$this->db->from('tema4ket');
		$this->db->join('siswa','siswa.nik=tema4ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}
	function tema5()
	{
		$this->db->select('*');
		$this->db->from('tema5');
		$this->db->join('siswa','siswa.nik=tema5.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema5ket()
	{
		$this->db->select('*');
		$this->db->from('tema5ket');
		$this->db->join('siswa','siswa.nik=tema5ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}


	function tema6()
	{
		$this->db->select('*');
		$this->db->from('tema6');
		$this->db->join('siswa','siswa.nik=tema6.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema6ket()
	{
		$this->db->select('*');
		$this->db->from('tema6ket');
		$this->db->join('siswa','siswa.nik=tema6ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}

	function tema7()
	{
		$this->db->select('*');
		$this->db->from('tema7');
		$this->db->join('siswa','siswa.nik=tema7.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema7ket()
	{
		$this->db->select('*');
		$this->db->from('tema7ket');
		$this->db->join('siswa','siswa.nik=tema7ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}

	function tema8()
	{
		$this->db->select('*');
		$this->db->from('tema8');
		$this->db->join('siswa','siswa.nik=tema8.nik');
		//$rata1 = 'tema1.a' * 'tema1.b'
		$query = $this->db->get();
		return $query->result();
	}

	function tema8ket()
	{
		$this->db->select('*');
		$this->db->from('tema8ket');
		$this->db->join('siswa','siswa.nik=tema8ket.nik');
//		$rata1ket = 'tema1ket.a' * 'tema1ket.b';
		$query = $this->db->get();
		return $query->result();
	}
}