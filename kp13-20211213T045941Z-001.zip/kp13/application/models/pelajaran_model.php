<?php
class pelajaran_model extends CI_Model
{
	public $table = 'pelajaran';
	public $id = 'id';
    public $order = 'DESC';

	public $labels = [];

	function __construct()
	{
		parent :: __construct();
		$this->labels = $this->_attributeLabels();
		$this->labels = $this->show_khstable();

		$this->load->database();
	}

	public function read()
	{
		$sql = "SELECT * FROM pelajaran ORDER BY id";
		$query = $this->db->query($sql);
		return $query->result();
	}

	function edit_data($where,$table)
	{		
		return $this->db->get_where($table,$where);
	}

	public function update_data($where,$data,$table)
    {
    	$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus_data($where)
	{
		$this->db->where($where);
		$this->db->delete('pelajaran');
	}

	function delete($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->delete($this->table, array("id" => $id));
    }

	// get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this-> $id);
        return $this->db->get($this->table,["id" => $id])->row();
    }


	private function _attributeLabels()
	{
		return[
			'kode'=> 'kode',
			'pelajaran'=> 'pelajaran',
			'guru'=> 'guru'
		];
	}
	public function show_khstable()
	{
		return $this->db->get('download');
	}
}