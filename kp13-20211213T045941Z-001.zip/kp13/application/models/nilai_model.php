<?php
class nilai_model extends CI_Model
{
	public $table = 'nilai';
	public $id = 'id';
    public $order = 'DESC';

	public $labels = [];

	function __construct()
	{
		parent :: __construct();
		$this->labels = $this->_attributeLabels();
		$this->labels = $this->show_khstable();

		$this->load->database();
	 }

	public function read()
	{
		$sql = "SELECT * FROM nilai ORDER BY id";
		$query = $this->db->query($sql);
		return $query->result();
	}

    function Tampiltema1() 
    {
        $this->db->select('*');
		$this->db->from('tema1');
		$this->db->join('siswa','siswa.nik=tema1.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema1_2() 
    {
        $this->db->select('*');
		$this->db->from('tema1ket');
		$this->db->join('siswa','siswa.nik=tema1ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema1($where)
	{
		return $this->db->get_where('tema1',$where);
	}

	public function update_tema1($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema1',$data);
	}

	function edit_Tema1ket($where)
	{
		return $this->db->get_where('tema1ket',$where);
	}

	public function update_tema1ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema1ket',$data);
	}

    function Tampiltema2() 
    {
        $this->db->select('*');
		$this->db->from('tema2');
		$this->db->join('siswa','siswa.nik=tema2.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema2_2() 
    {
        $this->db->select('*');
		$this->db->from('tema2ket');
		$this->db->join('siswa','siswa.nik=tema2ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema2($where)
	{
		return $this->db->get_where('tema2',$where);
	}

	public function update_tema2($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema2',$data);
	}

	function edit_Tema2ket($where)
	{
		return $this->db->get_where('tema2ket',$where);
	}

	public function update_tema2ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema2ket',$data);
	}

    function Tampiltema3() 
    {
        $this->db->select('*');
		$this->db->from('tema3');
		$this->db->join('siswa','siswa.nik=tema3.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema3_2() 
    {
        $this->db->select('*');
		$this->db->from('tema3ket');
		$this->db->join('siswa','siswa.nik=tema3ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema3($where)
	{
		return $this->db->get_where('tema3',$where);
	}

	public function update_tema3($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema3',$data);
	}

	function edit_Tema3ket($where)
	{
		return $this->db->get_where('tema3ket',$where);
	}

	public function update_tema3ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema3ket',$data);
	}

    function Tampiltema4() 
    {
        $this->db->select('*');
		$this->db->from('tema4');
		$this->db->join('siswa','siswa.nik=tema4.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema4_2() 
    {
        $this->db->select('*');
		$this->db->from('tema4ket');
		$this->db->join('siswa','siswa.nik=tema4ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema4($where)
	{
		return $this->db->get_where('tema4',$where);
	}

	public function update_tema4($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema4',$data);
	}

	function edit_Tema4ket($where)
	{
		return $this->db->get_where('tema4ket',$where);
	}

	public function update_tema4ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema4ket',$data);
	}

    function Tampiltema5() 
    {
        $this->db->select('*');
		$this->db->from('tema5');
		$this->db->join('siswa','siswa.nik=tema5.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema5_2() 
    {
        $this->db->select('*');
		$this->db->from('tema5ket');
		$this->db->join('siswa','siswa.nik=tema5ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema5($where)
	{
		return $this->db->get_where('tema5',$where);
	}

	public function update_tema5($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema5',$data);
	}

	function edit_Tema5ket($where)
	{
		return $this->db->get_where('tema5ket',$where);
	}

	public function update_tema5ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema5ket',$data);
	}

    function Tampiltema6() 
    {
        $this->db->select('*');
		$this->db->from('tema6');
		$this->db->join('siswa','siswa.nik=tema6.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema6_2() 
    {
        $this->db->select('*');
		$this->db->from('tema6ket');
		$this->db->join('siswa','siswa.nik=tema6ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema6($where)
	{
		return $this->db->get_where('tema6',$where);
	}

	public function update_tema6($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema6',$data);
	}

	function edit_Tema6ket($where)
	{
		return $this->db->get_where('tema6ket',$where);
	}

	public function update_tema6ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema6ket',$data);
	}

    function Tampiltema7() 
    {
        $this->db->select('*');
		$this->db->from('tema7');
		$this->db->join('siswa','siswa.nik=tema7.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema7_2() 
    {
        $this->db->select('*');
		$this->db->from('tema7ket');
		$this->db->join('siswa','siswa.nik=tema7ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema7($where)
	{
		return $this->db->get_where('tema7',$where);
	}

	public function update_tema7($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema7',$data);
	}

	function edit_Tema7ket($where)
	{
		return $this->db->get_where('tema7ket',$where);
	}

	public function update_tema7ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema7ket',$data);
	}

    function Tampiltema8() 
    {
        $this->db->select('*');
		$this->db->from('tema8');
		$this->db->join('siswa','siswa.nik=tema8.nik');
		$query = $this->db->get();
		return $query->result();
    }

    function Tampiltema8_2() 
    {
        $this->db->select('*');
		$this->db->from('tema8ket');
		$this->db->join('siswa','siswa.nik=tema8ket.nik');
		$query = $this->db->get();
		return $query->result();
    }

	function edit_Tema8($where)
	{
		return $this->db->get_where('tema8',$where);
	}

	public function update_tema8($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema8',$data);
	}

	function edit_Tema8ket($where)
	{
		return $this->db->get_where('tema8ket',$where);
	}

	public function update_tema8ket($where,$data)
    {    	
    	$this->db->where($where);
	    $this->db->update('tema8ket',$data);
	}

	// get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this-> $id);
        return $this->db->get($this->table,["id" => $id])->row();
    }

	function total_rows($q = NULL) 
	{
        $this->db->like('id', $q);
		$this->db->or_like('nik', $q);
		$this->db->or_like('nama', $q);
		$this->db->or_like('kelas', $q);
		$this->db->or_like('alamat', $q);

		$this->db->from($this->table);
	        return $this->db->count_all_results();
    }

    function get_limit_data($limit, $start = 0, $q = NULL) 
    {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id', $q);
		$this->db->or_like('nik', $q);
		$this->db->or_like('nama', $q);
		$this->db->or_like('kelas', $q);
		$this->db->or_like('alamat', $q);


		$this->db->limit($limit, $start);
	        return $this->db->get($this->table);
    }

    //cek nip dan password dosen
    function auth($username,$password){
        $query=$this->db->query("SELECT * FROM user WHERE unique_id='$username' AND password=MD5('$password') LIMIT 1");
        return $query;
    }
    function signup($username = 0){
		$this->load->helper('url');
		$cek = url_title($this->input_->post('username'), 'dash', TRUE);
		$data = array(
			'unique_id' => $this->input_->post('username'), 
			'username' => $this->input_->post('fname'), 
			'password' => md5($this->input_->post('password')),
			'level' => 2
		);
		if ($username == 0){
			return $this->db->insert('user', $data);
		} else {
			$url=base_url('');
            echo $this->session->set_flashdata('msg','Username sudah ada');
            redirect($url);
		}
	}

	private function _attributeLabels()
	{
		return[
			'nik'=> 'nik',
			'nama'=> 'nama',
			'kelas'=> 'kelas',
			'alamat'=> 'alamat'
		];
	}
	public function show_khstable()
	{
		return $this->db->get('download');
	}
}